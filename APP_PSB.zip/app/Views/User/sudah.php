<?= $this->extend('layouts/siswa_template'); ?>
<?= $this->section('content'); ?>

<div class="container-fluid">

<br><br><br><br>
<!-- 404 Error Text -->
<div class="text-center">
    <div class="error mx-auto" data-text="Diterima">Diterima</div>
    <p class="lead text-gray-800 mx-auto">Anda Telah Diterima <br> Silahkan Cetak Status Pendaftaran</p>

</div>

</div>

<?= $this->endSection(); ?>