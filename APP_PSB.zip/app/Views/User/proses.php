<?= $this->extend('layouts/siswa_template'); ?>
<?= $this->section('content'); ?>

<div class="container-fluid">

<br><br><br><br>
<!-- 404 Error Text -->
<div class="text-center">
    <div class="error mx-auto" data-text="Proses">Proses</div>
    <p class="lead text-gray-800 mx-auto">Anda Telah Mendaftar <br> Silahkan Menunggu Proses Penerimaan</p>

</div>

</div>

<?= $this->endSection(); ?>