<?= $this->include('layouts/admin_header'); ?>
<?= $this->include('layouts/admin_sidebar'); ?>
<?= $this->renderSection('content'); ?>
