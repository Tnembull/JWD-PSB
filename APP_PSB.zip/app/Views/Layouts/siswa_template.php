<?= $this->include('layouts/siswa_header'); ?>
<?= $this->renderSection('content'); ?>
<?= $this->include('layouts/siswa_footer'); ?>